place here a standalone copy of puredata (with  vstschedlib.dll & pthreadGC-3.dll copied in \bin directory)


This way you can distribute your plugins by copying only 3 items inthe VST standard folder :
* your_plugin.dll
* your_plugin\  folder
* this \.pd\ folder